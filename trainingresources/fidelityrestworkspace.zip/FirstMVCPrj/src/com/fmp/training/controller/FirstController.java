package com.fmp.training.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class FirstController {
	
	@RequestMapping(value = "/first.req",produces = "text/html")
	 
	@ResponseBody public String getMessage()
	{
		return "<html><body><h2>Welcome to Spring MVC</h2></body></html>";
	}

}
