package com.fmr.training.repository;

import java.util.TreeMap;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDAO {
	private TreeMap<Integer, Employee> map=new TreeMap<>();
	
	public EmployeeDAO()
	{
		map.put(1001, new Employee(1001, "Rajesh", "Accountant", 50000));
		map.put(1002, new Employee(1002, "Deva", "Developer", 70000));
		map.put(1003, new Employee(1003, "Suresh", "Accountant", 80000));
	}
	
	public Employee findEmployee(int id)
	{
		return map.get(id);
	}

}
