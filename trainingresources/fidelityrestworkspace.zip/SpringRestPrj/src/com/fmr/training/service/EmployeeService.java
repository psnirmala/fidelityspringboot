package com.fmr.training.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fmr.training.repository.Employee;
import com.fmr.training.repository.EmployeeDAO;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeDAO dao;
	
	public Optional<Employee> getEmployeeDetails(int id)
	{
		Employee e=dao.findEmployee(id);
		if(e==null){
			return Optional.empty();
		}
		else{
			return Optional.of(e);
		}
	}
	
	

}
