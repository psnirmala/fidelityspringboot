package com.fmr.training.rest.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDAO {
	private TreeMap<Integer, Employee> map=new TreeMap<>();
	
	public EmployeeDAO()
	{
		map.put(1001, new Employee(1001, "Rajesh", "Accountant", 50000));
		map.put(1002, new Employee(1002, "Deva", "Developer", 70000));
		map.put(1003, new Employee(1003, "Suresh", "Accountant", 80000));
	}
	
	public Employee findEmployee(int id)
	{
		return map.get(id);
	}

	public List<Employee> getAllEmployees()
	{
		return new ArrayList<Employee>(map.values());
	}
	
	public int addEmployee(Employee e)
	{
		int nextId=map.lastKey()+1;
		e.setEmpId(nextId);
		map.put(nextId, e);
		return nextId;
	}
	
	public boolean updateEmployee(int id,Employee e)
	{
		Employee emp=map.get(id);
		if(emp==null) {
			return false;
		}
		else {
			emp.setName(e.getName());
			emp.setDesignation(e.getDesignation());
			emp.setSalary(e.getSalary());
			return true;
		}
	}
	
	public boolean removeEmployee(int id)
	{
		Employee emp=map.get(id);
		if(emp==null) {
			return false;
		}
		else {
			map.remove(id);
			return true;
		}
	}
	
	
}
