package com.fmr.training.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fmr.training.rest.repository.Employee;
import com.fmr.training.rest.repository.EmployeeDAO;



@Service
public class EmployeeService {
	@Autowired
	private EmployeeDAO dao;
	
	public Optional<Employee> getEmployeeDetails(int id)
	{
		Employee e=dao.findEmployee(id);
		if(e==null){
			return Optional.empty();
		}
		else{
			return Optional.of(e);
		}
	}
	
	public List<Employee> getAllEmployees()
	{
		return dao.getAllEmployees();
	}

	public int addEmployee(Employee e)
	{
		return dao.addEmployee(e);
	}
	
	public boolean updateEmployee(int id,Employee e)
	{
		return dao.updateEmployee(id, e);
	}
	
	public boolean removeEmployee(int id)
	{
		return dao.removeEmployee(id);
	}
}
