package com.fmr.training.itemorder.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fmr.training.itemorder.domain.ItemOrder;
import com.fmr.training.itemorder.service.ItemOrderService;

@RestController
@RequestMapping("/itemorder")
public class ItemOrderController {

	@Autowired
	private ItemOrderService service;
	
	@GetMapping("/{code}/quantity/{qty}")
	public ItemOrder placeItemOrder(@PathVariable("code")int itemCode,
			@PathVariable("qty") int quantity)
	{
		return service.placeOrder(itemCode, quantity);
	}
}
