package com.fmr.training.itemorder.domain;

public class ItemOrder {
	private int itemId;
	private String name;
	private double totalAmount;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public ItemOrder(int itemId, String name, double totalAmount) {
		super();
		this.itemId = itemId;
		this.name = name;
		this.totalAmount = totalAmount;
	}
	public ItemOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
