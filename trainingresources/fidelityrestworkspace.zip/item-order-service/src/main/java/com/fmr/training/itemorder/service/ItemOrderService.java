package com.fmr.training.itemorder.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fmr.training.itemorder.domain.Item;
import com.fmr.training.itemorder.domain.ItemOrder;
import com.fmr.training.itemorder.proxy.ItemProxy;

@Service
public class ItemOrderService {
	
	@Autowired
	private ItemProxy proxy;
	
	@Autowired
	private RestTemplate template;
	
	
	
	public ItemOrder placeOrder(int itemCode,int quantity)
	{
		Item item=proxy.getItem(itemCode);
		ItemOrder order=new ItemOrder();
		order.setItemId(itemCode);
	//	String serverPort=environment.getProperty("local.server.port");
		order.setName(item.getName());
		order.setTotalAmount(quantity*item.getPrice());
		return order;
	}

	
	  public ItemOrder placeOrderWithoutFeign(int itemCode,int quantity) 
	  { 
	String
	  url="http://localhost:8081/item/"+itemCode; 
	  Item
	  item=template.getForObject(url, Item.class);
	  double price=item.getPrice();
	  double totalAmount=quantity*price; 
	  return new ItemOrder(itemCode,	  item.getName(), totalAmount);
	  }
	 
}
