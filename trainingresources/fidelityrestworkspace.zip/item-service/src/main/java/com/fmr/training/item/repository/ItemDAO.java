package com.fmr.training.item.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.fmr.training.item.domain.Item;

@Repository
public class ItemDAO {

	private Map<Integer, Item> itemList=new HashMap<>();
	public ItemDAO()
	{
		itemList.put(101, new Item(101, "Apple", 20));
		itemList.put(102, new Item(102, "Orange", 10));
		itemList.put(103, new Item(103, "Mango", 40));
	}
	public Item findItem(int itemId)
	{
		return itemList.get(itemId);
	}
}
