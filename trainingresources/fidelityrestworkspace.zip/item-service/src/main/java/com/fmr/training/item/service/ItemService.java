package com.fmr.training.item.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fmr.training.item.domain.Item;
import com.fmr.training.item.repository.ItemDAO;

@Service
public class ItemService {
	
	@Autowired
	private ItemDAO dao;
	@Autowired
	private Environment environment;
	
	public Item getItem(int id)
	{
	Item item= dao.findItem(id);
	String port=environment.getProperty("local.server.port");
	item.setName(item.getName()+" from "+port);
	return item;
	}

}
