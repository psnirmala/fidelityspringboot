package com.fmr.training.restwithjpa.exceptions;

import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice
public class ExceptionResponseHandler extends ResponseEntityExceptionHandler{

	@ExceptionHandler(EmployeeNotFoundException.class)
	protected ResponseEntity<Object> 
	handleEmployeeNotFoundException(EmployeeNotFoundException ex, WebRequest request) {
		// TODO Auto-generated method stub
		ExceptionResponseEntity entity=new ExceptionResponseEntity();
		entity.setTimestamp(new Date());
		entity.setMessage(ex.getMessage());
		entity.setDetails(request.getDescription(false));
		
		return new ResponseEntity<Object>(entity, HttpStatus.NOT_FOUND);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		ExceptionResponseEntity entity=new ExceptionResponseEntity();
		entity.setTimestamp(new Date());
		entity.setMessage("validation failed");
		entity.setDetails(ex.getBindingResult().toString());
		return new ResponseEntity<Object>(entity, HttpStatus.BAD_REQUEST);
	}

	
	

}
