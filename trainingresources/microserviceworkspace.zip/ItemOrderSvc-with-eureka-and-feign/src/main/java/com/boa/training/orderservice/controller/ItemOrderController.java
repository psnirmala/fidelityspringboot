package com.boa.training.orderservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.training.orderservice.domain.ItemOrder;
import com.boa.training.orderservice.service.ItemOrderService;

@RestController
@RequestMapping("/itemorder")
public class ItemOrderController {
	@Autowired
	private ItemOrderService orderService;
	
	@GetMapping(value = "/{code}/quantity/{qty}",
			produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<ItemOrder> getItemOrderDetails
	(@PathVariable("code")int itemCode,@PathVariable("qty")int quantity)
	
	{
		System.out.println("controller");
		return 
				new ResponseEntity<ItemOrder>(orderService.getItemOrderDataThroughFeign(itemCode, 
				quantity),HttpStatus.OK);
	}
	

}
