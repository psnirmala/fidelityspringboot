package com.boa.training.restspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionsRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionsRestApplication.class, args);
	}

}
