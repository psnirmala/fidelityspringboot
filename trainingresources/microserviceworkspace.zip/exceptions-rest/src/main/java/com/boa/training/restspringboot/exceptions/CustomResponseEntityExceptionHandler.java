package com.boa.training.restspringboot.exceptions;

import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestController
@ControllerAdvice
public class CustomResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(EmployeeNotFoundException.class)
	protected ResponseEntity<Object> handleEmployeeNotFoundException(EmployeeNotFoundException ex,
			WebRequest request) {
		// TODO Auto-generated method stub
		return new ResponseEntity(new ExceptionResponseEntity(new Date(), ex.getMessage(), request.getDescription(true)),HttpStatus.NOT_FOUND);
	
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		return new ResponseEntity(new ExceptionResponseEntity(new Date(), "Validation failed", ex.getBindingResult().toString()),HttpStatus.NOT_FOUND);
	}
	
	
	
}
